#include <stdio.h>
#include <stdlib.h>

double Delta(double, double, double);
double Pierw(double, double, double, int);
double* PierwZesp(double, double, double, int);